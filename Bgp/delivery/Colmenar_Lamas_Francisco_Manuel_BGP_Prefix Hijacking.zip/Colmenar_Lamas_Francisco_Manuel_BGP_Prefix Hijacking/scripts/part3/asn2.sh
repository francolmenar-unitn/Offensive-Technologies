#!/bin/bash

vtysh -c "show ip bgp"